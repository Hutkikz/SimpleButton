

#include "Arduino.h"
#include "SimpleButton.h"


SimpleButton::SimpleButton()
{ // default values
  _interval = 10;            // 10ms
  _numIntervalsPress = 3;    // 10ms - 2 reads=1 interval   (Actually number of intervals * 2 + 1 )
  _numIntervalsRelease = 2;  // 50ms - 6 reads=5 intervals  (Actually number of intervals out of 7 to ignore)
}


SimpleButton::SimpleButton(unsigned long interval, byte pressIntervals, byte releaseIntervals)
{
  _interval = interval;  // number of ms per interval
  _numIntervalsPress = (pressIntervals * 2) + 1;  // Acceptable values = 0(no debounce) - 7(max debounce)
  _numIntervalsRelease = (7 - releaseIntervals);  // Acceptable values = 0(no debounce) - 7(max debounce)
}


void SimpleButton::setup(byte pin)
{
  _buttonPin = pin;
  pinMode(_buttonPin, INPUT_PULLUP);
}


byte SimpleButton::update()
{
  _currentTime = millis();
  _buttonState = 0;

  if (_currentTime - _startTime >= _interval)
  {
    _startTime += _interval;  // reset Timer

    if (digitalRead (_buttonPin))  // button IS NOT pressed so shift a 0 into the buffer
    {
      _buttonBuffer = _buttonBuffer << 1;
    }
    else                 // button IS pressed so shift in a 1
    {
      _buttonBuffer = ( _buttonBuffer << 1) + 1;
    }

    if (_buttonIsNowPressed == false)
    {
      if ((_buttonBuffer & _numIntervalsPress) == _numIntervalsPress)  //  press debounce
      {
        _buttonIsNowPressed = true;
        _buttonState = 1;  // confirmed button press
      }
    }
    else
    {
      if ((_buttonBuffer << _numIntervalsRelease) == 0)  //  release debounce
      {
        _buttonIsNowPressed = false;
      }
    }
  }
  return _buttonState;
}
