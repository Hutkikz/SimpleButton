

#ifndef SimpleButton_h
#define SimpleButton_h

#include "Arduino.h"


class SimpleButton
{
  public:
    SimpleButton();
    SimpleButton(unsigned long interval, byte press, byte release);
    void setup(byte pin);
    byte update();

  private:
    byte _buttonPin;
    byte _buttonBuffer;  // ring buffer to store last 8 buttonReads
    byte _numIntervalsPress;
    byte _numIntervalsRelease;
	byte _pressTable [8] = {1, 3, 7, 15, 31, 63, 127, 255};
    bool _buttonIsNowPressed = false;
    byte _buttonState;
    unsigned long _interval;
    unsigned long _startTime;
    unsigned long _currentTime;
	
};

#endif
